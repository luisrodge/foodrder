create function make_random_id() returns bigint
LANGUAGE SQL
AS $$
select pseudo_encrypt(nextval('random_int_seq')::int) as bigint
$$;
